export declare function warnOnce(msg: string): void;
