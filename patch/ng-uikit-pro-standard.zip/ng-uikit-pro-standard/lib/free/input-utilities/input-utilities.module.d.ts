export declare class InputUtilitiesModule {
}
