export declare class BadgeModule {
}
