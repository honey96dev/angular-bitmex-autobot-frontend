export { WavesDirective } from './waves-effect.directive';
export { WavesModule } from './waves.module';
