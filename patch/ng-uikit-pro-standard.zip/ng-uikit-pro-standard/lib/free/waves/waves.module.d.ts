import { ModuleWithProviders } from '@angular/core';
export declare class WavesModule {
    static forRoot(): ModuleWithProviders;
}
