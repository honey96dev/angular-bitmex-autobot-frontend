import { ElementRef, OnInit, Renderer2 } from '@angular/core';
export declare class MdbBreadcrumbItemComponent implements OnInit {
    private _el;
    private _renderer;
    fontWeight: string;
    constructor(_el: ElementRef, _renderer: Renderer2);
    ngOnInit(): void;
}
