export declare class BreadcrumbModule {
}
