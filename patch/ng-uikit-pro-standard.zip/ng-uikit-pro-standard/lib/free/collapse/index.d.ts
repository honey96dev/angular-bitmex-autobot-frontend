export { CollapseComponent } from './collapse.component';
export { CollapseModule } from './collapse.module';
