import { ModuleWithProviders } from '@angular/core';
export declare class PopoverModule {
    static forRoot(): ModuleWithProviders;
}
