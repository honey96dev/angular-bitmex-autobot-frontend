export declare class TableModule {
}
