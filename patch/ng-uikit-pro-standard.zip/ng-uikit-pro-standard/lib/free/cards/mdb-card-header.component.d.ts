import { OnInit, ElementRef, Renderer2 } from '@angular/core';
export declare class MdbCardHeaderComponent implements OnInit {
    private _el;
    private _r;
    class: string;
    constructor(_el: ElementRef, _r: Renderer2);
    ngOnInit(): void;
}
