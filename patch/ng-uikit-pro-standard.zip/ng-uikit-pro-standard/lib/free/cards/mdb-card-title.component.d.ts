import { OnInit, ElementRef, Renderer2 } from '@angular/core';
export declare class MdbCardTitleComponent implements OnInit {
    private _el;
    private _r;
    constructor(_el: ElementRef, _r: Renderer2);
    ngOnInit(): void;
}
