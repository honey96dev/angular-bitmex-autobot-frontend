import { ElementRef, Renderer2, OnInit } from '@angular/core';
export declare class MdbCardBodyComponent implements OnInit {
    private _el;
    private _r;
    class: string;
    cascade: boolean;
    constructor(_el: ElementRef, _r: Renderer2);
    ngOnInit(): void;
}
