export declare class MdbCardTextComponent {
    class: string;
}
