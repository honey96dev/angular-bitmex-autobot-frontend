export declare class IconsModule {
}
