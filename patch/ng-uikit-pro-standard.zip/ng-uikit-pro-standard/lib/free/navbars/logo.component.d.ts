export declare class LogoComponent {
}
