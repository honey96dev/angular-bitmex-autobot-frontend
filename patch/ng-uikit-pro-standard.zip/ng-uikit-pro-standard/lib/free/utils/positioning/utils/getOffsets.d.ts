import { Data, Offsets } from '../models/index';
export declare function getOffsets(data: Data): Offsets;
