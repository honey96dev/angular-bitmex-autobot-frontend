export declare function isIE(version?: number): boolean;
