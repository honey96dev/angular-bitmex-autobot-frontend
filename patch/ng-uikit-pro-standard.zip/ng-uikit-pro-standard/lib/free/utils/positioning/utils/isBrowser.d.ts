export declare const isBrowser: boolean;
