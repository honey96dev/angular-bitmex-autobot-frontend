import { Offsets } from '../models/index';
export declare function getViewportOffsetRectRelativeToArtbitraryNode(element: any, excludeScroll?: boolean): Offsets;
