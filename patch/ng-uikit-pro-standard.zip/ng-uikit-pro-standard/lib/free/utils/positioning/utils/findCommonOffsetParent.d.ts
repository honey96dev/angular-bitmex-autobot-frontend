export declare function findCommonOffsetParent(element1: HTMLElement, element2: HTMLElement): any;
