/**
 * Get the opposite placement variation of the given one
 */
export declare function getOppositeVariation(variation: string): string;
