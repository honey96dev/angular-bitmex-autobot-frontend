/**
 * Tells if a given input is a number
 */
export declare function isNumeric(n: any): boolean;
