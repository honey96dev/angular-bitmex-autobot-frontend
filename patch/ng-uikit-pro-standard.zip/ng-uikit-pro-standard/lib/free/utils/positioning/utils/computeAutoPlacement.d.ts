export declare function computeAutoPlacement(placement: string, refRect: any, target: HTMLElement, host: HTMLElement, allowedPositions?: any[], boundariesElement?: string, padding?: number): string;
