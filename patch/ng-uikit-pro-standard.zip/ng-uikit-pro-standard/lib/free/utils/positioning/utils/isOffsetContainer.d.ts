export declare function isOffsetContainer(element: any): boolean;
