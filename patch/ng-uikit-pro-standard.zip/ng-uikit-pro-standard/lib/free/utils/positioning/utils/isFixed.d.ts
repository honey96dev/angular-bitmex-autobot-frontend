export declare function isFixed(element: HTMLElement): boolean;
