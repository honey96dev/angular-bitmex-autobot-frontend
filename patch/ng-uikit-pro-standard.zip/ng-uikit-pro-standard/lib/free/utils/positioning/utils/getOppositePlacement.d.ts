/**
 * Get the opposite placement of the given one
 */
export declare function getOppositePlacement(placement: string): string;
