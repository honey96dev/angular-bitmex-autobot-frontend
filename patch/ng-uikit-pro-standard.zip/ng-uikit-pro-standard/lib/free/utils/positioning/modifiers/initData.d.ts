import { Data, Options } from '../models/index';
export declare function initData(targetElement: HTMLElement, hostElement: HTMLElement, position: string, options: Options): Data;
