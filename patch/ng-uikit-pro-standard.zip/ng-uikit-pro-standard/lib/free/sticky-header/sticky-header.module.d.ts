export declare class StickyHeaderModule {
}
