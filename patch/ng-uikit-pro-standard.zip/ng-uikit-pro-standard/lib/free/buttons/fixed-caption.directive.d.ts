import { ElementRef, OnInit, Renderer2 } from '@angular/core';
export declare class FixedButtonCaptionDirective implements OnInit {
    private renderer;
    private el;
    caption: string;
    collapseButtonActivator: any;
    private paragraphEl;
    constructor(renderer: Renderer2, el: ElementRef);
    ngOnInit(): void;
    createCaptionElement(): void;
    showCaption(): void;
}
