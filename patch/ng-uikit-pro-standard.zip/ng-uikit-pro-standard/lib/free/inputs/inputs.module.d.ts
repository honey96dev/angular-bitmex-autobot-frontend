import { ModuleWithProviders } from '@angular/core';
export declare class InputsModule {
    static forRoot(): ModuleWithProviders;
}
