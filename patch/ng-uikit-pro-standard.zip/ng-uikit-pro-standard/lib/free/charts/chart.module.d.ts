export declare class ChartsModule {
}
