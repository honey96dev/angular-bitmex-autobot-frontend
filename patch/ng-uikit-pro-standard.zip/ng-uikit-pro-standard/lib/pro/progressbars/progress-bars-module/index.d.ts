import { ModuleWithProviders } from '@angular/core';
export { ProgressBarComponent } from './progressbar.component';
export declare class MdProgressBarModule {
    /** @deprecated */
    static forRoot(): ModuleWithProviders;
}
