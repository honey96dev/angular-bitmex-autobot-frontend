export declare class StepperModule {
}
