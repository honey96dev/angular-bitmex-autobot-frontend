export declare class MdbCvvDirective {
    maxLength: string;
    onInput(event: any): void;
    formatInput(event: any): void;
    getFormattedValue(value: string): string;
    removeNonDigits(value: string): string;
}
