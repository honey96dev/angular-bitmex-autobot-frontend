export declare class AutoFormatModule {
}
