export declare class ChartSimpleModule {
}
