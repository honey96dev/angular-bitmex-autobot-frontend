export declare class RangeModule {
}
