import { ElementRef } from '@angular/core';
export declare class MdbAutoCompleterOptionDirective {
    private _el;
    value: string;
    constructor(_el: ElementRef);
}
