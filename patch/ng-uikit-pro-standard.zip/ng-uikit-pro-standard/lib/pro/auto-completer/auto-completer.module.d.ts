export declare class AutoCompleterModule {
}
