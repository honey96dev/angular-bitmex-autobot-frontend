export declare class DatepickerModule {
}
