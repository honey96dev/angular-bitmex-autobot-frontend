export interface IMyMarkedDate {
    marked: boolean;
    color: string;
}
