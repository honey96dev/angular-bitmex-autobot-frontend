export declare class TimePickerModule {
}
