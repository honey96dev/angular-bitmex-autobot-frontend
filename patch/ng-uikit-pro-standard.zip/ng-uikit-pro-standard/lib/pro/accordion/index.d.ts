import { SqueezeBoxComponent } from './components/squeezebox';
import { SBItemComponent } from './components/sb-item';
import { SBItemHeadComponent } from './components/sb-item.head';
import { SBItemBodyComponent } from './components/sb-item.body';
export declare const SQUEEZEBOX_COMPONENTS: (typeof SBItemBodyComponent | typeof SBItemComponent | typeof SqueezeBoxComponent | typeof SBItemHeadComponent)[];
export { SBItemComponent } from './components/sb-item';
export { SBItemHeadComponent } from './components/sb-item.head';
export { SBItemBodyComponent } from './components/sb-item.body';
export { SqueezeBoxComponent } from './components/squeezebox';
export declare class AccordionModule {
}
