import { SBItemComponent } from './components/sb-item';
export declare class MdbAccordionService {
    private _items;
    private _multiple;
    addItem(item: SBItemComponent): void;
    updateItemsArray(items: SBItemComponent[]): void;
    updateMultipleState(value: boolean): void;
    didItemToggled(item: SBItemComponent): void;
}
