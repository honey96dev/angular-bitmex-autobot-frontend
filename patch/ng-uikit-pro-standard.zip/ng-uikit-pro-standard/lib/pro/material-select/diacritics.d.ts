export declare class Diacritics {
    static DIACRITICS: any;
    static strip(text: string): string;
}
