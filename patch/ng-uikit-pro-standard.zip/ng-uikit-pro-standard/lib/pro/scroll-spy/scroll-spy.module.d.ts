export declare class ScrollSpyModule {
}
