export declare class ChipsModule {
}
