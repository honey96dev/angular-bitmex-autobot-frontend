export declare class SidenavModule {
}
