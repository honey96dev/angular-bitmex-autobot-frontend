export declare class FileInputModule {
}
